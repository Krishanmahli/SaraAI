package com.sara.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 41;
    private LinearLayout root, messages;
    private EditText input, apiKey;
    private TextView status;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("hi", "IN"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        addMessage("नमस्ते! मैं SARA हूँ। मुझसे हिंदी में बात करें।", false);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.WHITE); return t;
    }
    private void buildUi() {
        ScrollView page = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(dp(18), dp(24), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(13, 18, 36));
        page.addView(root);
        setContentView(page);

        TextView title = label("✦ SARA AI", 28);
        title.setTypeface(null, Typeface.BOLD); root.addView(title);
        TextView subtitle = label("आपकी हिंदी Voice Assistant", 14);
        subtitle.setTextColor(Color.LTGRAY); root.addView(subtitle);
        status = label("● तैयार हूँ", 13); status.setTextColor(Color.rgb(90,220,170));
        root.addView(status);

        messages = new LinearLayout(this); messages.setOrientation(1);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(250));
        mp.topMargin = dp(18); root.addView(messages, mp);

        input = new EditText(this); input.setSingleLine(false);
        input.setHint("यहाँ अपना सवाल लिखें…"); input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY); input.setBackgroundColor(Color.rgb(31,40,65));
        root.addView(input, new LinearLayout.LayoutParams(-1, dp(54)));

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(0);
        root.addView(actions);
        addButton(actions, "भेजें", v -> sendChat());
        addButton(actions, "🎙 बोलें", v -> startVoice());
        addButton(actions, "मौसम", v -> getWeather());
        addButton(actions, "ऐप खोलें", v -> openApp());

        TextView keyTitle = label("AI API Key (Gemini)", 14);
        keyTitle.setPadding(0, dp(18), 0, dp(4)); root.addView(keyTitle);
        apiKey = new EditText(this); apiKey.setSingleLine(true);
        apiKey.setHint("अपनी Gemini API key डालें");
        apiKey.setTextColor(Color.WHITE); apiKey.setHintTextColor(Color.LTGRAY);
        apiKey.setBackgroundColor(Color.rgb(31,40,65));
        root.addView(apiKey, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView note = label("API key निजी रखें। इस ऐप में यह केवल आपके फोन पर सेव रहती है।", 11);
        note.setTextColor(Color.LTGRAY); root.addView(note);
    }

    private void addButton(LinearLayout row, String text, View.OnClickListener click) {
        Button b = new Button(this); b.setText(text); b.setOnClickListener(click);
        row.addView(b, new LinearLayout.LayoutParams(0, dp(52), 1));
    }
    private void addMessage(String text, boolean user) {
        TextView t = label((user ? "आप: " : "SARA: ") + text, 15);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackgroundColor(user ? Color.rgb(35,70,110) : Color.rgb(37,48,75));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5)); messages.addView(t, p);
    }
    private void speak(String text) {
        if (tts != null && ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sara_reply");
    }
    private void sendChat() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        input.setText(""); addMessage(q, true);
        String key = apiKey.getText().toString().trim();
        if (key.isEmpty()) { String msg = "AI chat के लिए Gemini API key डालें। मौसम और ऐप खोलना बिना key के भी चलेगा।"; addMessage(msg,false); speak(msg); return; }
        status.setText("● जवाब तैयार कर रही हूँ…");
        new Thread(() -> {
            String answer = askGemini(key, q);
            runOnUiThread(() -> { status.setText("● तैयार हूँ"); addMessage(answer,false); speak(answer); });
        }).start();
    }
    private String askGemini(String key, String question) {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + URLEncoder.encode(key, "UTF-8"));
            c = (HttpURLConnection)u.openConnection(); c.setRequestMethod("POST");
            c.setConnectTimeout(15000); c.setReadTimeout(25000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json");
            JSONObject part = new JSONObject().put("text", "हिंदी में सरल और सुरक्षित जवाब दें: " + question);
            JSONObject body = new JSONObject().put("contents", new org.json.JSONArray().put(new JSONObject().put("parts", new org.json.JSONArray().put(part))));
            try(OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            String response = read(c.getInputStream());
            JSONObject obj = new JSONObject(response);
            return obj.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text");
        } catch(Exception e) { return "माफ़ कीजिए, AI से कनेक्ट नहीं हो पाया। API key और इंटरनेट जाँचें।"; }
        finally { if(c != null) c.disconnect(); }
    }
    private String read(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int n;
        while((n=in.read(buf))!=-1) out.write(buf,0,n);
        return out.toString("UTF-8");
    }
    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { addMessage("इस फोन में Speech Recognition उपलब्ध नहीं है।",false); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए, SARA सुन रही है");
        try { startActivityForResult(i, 42); } catch(Exception e) { addMessage("Voice input शुरू नहीं हुआ।",false); }
    }
    @Override protected void onActivityResult(int r, int code, Intent data) {
        super.onActivityResult(r,code,data);
        if(r==42 && code==RESULT_OK && data!=null) {
            ArrayList<String> a=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(a!=null && !a.isEmpty()) { input.setText(a.get(0)); sendChat(); }
        }
    }
    private void getWeather() {
        status.setText("● मौसम देख रही हूँ…");
        new Thread(() -> {
            String result;
            try {
                // Open-Meteo demo coordinates: Bengaluru. Change to your city coordinates if needed.
                URL u = new URL("https://api.open-meteo.com/v1/forecast?latitude=12.9716&longitude=77.5946&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m");
                HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(12000);
                JSONObject current = new JSONObject(read(c.getInputStream())).getJSONObject("current");
                result = "बेंगलुरु का मौसम: तापमान " + current.getDouble("temperature_2m") + "°C, महसूस " +
                    current.getDouble("apparent_temperature") + "°C, नमी " + current.getInt("relative_humidity_2m") +
                    "% और हवा " + current.getDouble("wind_speed_10m") + " km/h.";
                c.disconnect();
            } catch(Exception e) { result="मौसम की जानकारी नहीं मिल सकी। इंटरनेट जाँचें।"; }
            final String msg=result;
            runOnUiThread(() -> { status.setText("● तैयार हूँ"); addMessage(msg,false); speak(msg); });
        }).start();
    }
    private void openApp() {
        String q=input.getText().toString().trim().toLowerCase(Locale.ROOT);
        if(q.isEmpty()) { addMessage("पहले नीचे लिखें: YouTube, Chrome, WhatsApp या Settings",false); return; }
        String pkg = q.contains("youtube") ? "com.google.android.youtube" :
            (q.contains("chrome") ? "com.android.chrome" :
            (q.contains("whatsapp") ? "com.whatsapp" :
            (q.contains("setting") ? "com.android.settings" : "")));
        if(pkg.isEmpty()) { addMessage("अभी YouTube, Chrome, WhatsApp और Settings खोल सकती हूँ।",false); return; }
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch!=null) startActivity(launch); else addMessage("यह ऐप फोन में इंस्टॉल नहीं है।",false);
    }
    @Override protected void onDestroy() {
        if(tts!=null) { tts.stop(); tts.shutdown(); }
        if(recognizer!=null) recognizer.destroy();
        super.onDestroy();
    }
}
