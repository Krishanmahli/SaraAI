# SARA AI — Android Hindi Voice Assistant

A starter Android project with:
- Hindi speech input using Android speech recognition (`hi-IN`)
- Hindi text-to-speech replies
- Gemini AI chat (user enters their own API key)
- Weather from Open-Meteo (currently configured for Bengaluru)
- Launch shortcuts for YouTube, Chrome, WhatsApp, and Settings
- GitHub Actions workflow to build a debug APK

## Important notes
- This is a starter project, not a finished production assistant.
- Gemini API key is entered on-device. Do not commit keys to GitHub. For a public app, put AI requests behind your own authenticated backend; a key embedded in an APK can be extracted.
- Weather coordinates are currently set to Bengaluru. Change latitude/longitude in `MainActivity.java` for another city.
- Speech recognition depends on a speech service installed on the Android phone and may require internet.
- App launching currently supports a small fixed list. It does not secretly access other apps or data.

## Build APK with GitHub Actions (phone-only workflow)
1. Create a new public or private GitHub repository named `SARA-AI`.
2. Upload all files and folders from this project to the repository root. Keep `.github/workflows/android.yml` in that exact path.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build SARA AI APK** → **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `SARA-AI-debug-apk`.
8. Extract the ZIP and install `app-debug.apk` on your Android phone. If Android asks, allow installation from that browser/file manager for this one install.

## Local build
Requires JDK 17, Android SDK platform 35, and Gradle 8.9:
```bash
gradle assembleDebug
```

## Change weather city
Edit the Open-Meteo URL in `MainActivity.java`:
- `latitude=12.9716`
- `longitude=77.5946`
Use coordinates for your city.

## Troubleshooting
- If GitHub Actions fails at SDK setup or compilation, open the failed step and share a screenshot or log.
- If voice input does not work, check Android microphone permission and that Google speech services are available.
